import java.sql.*;
import java.util.Date;
import java.util.ArrayList;

import tuc.eced.cs201.io.StandardInputRead;

public class MainClass {
	public ArrayList<String> logs;
	public Connection conn;
	public StandardInputRead sir;
	public boolean cont = true;
	public boolean trans = false;
	public String email = null;
	
	public MainClass(){
		logs= new ArrayList<String>();
		try {
     		Class.forName("org.postgresql.Driver");
		} catch(Exception e) {
            e.printStackTrace();
		}
	}
	
	public static void main(String [] args) throws SQLException{
		MainClass main = new MainClass();
		main.sir = new StandardInputRead();
		while (main.cont){
			main.Menu();
			main.ChoiceProc();
		}
	}
	
	public void Menu(){
		System.out.println("1. Connect to Database");
		System.out.println("2. Start transaction");
		System.out.println("3. Cancel transaction");
		System.out.println("4. Commit transaction");
		System.out.println("5. Find professional network of user");
		System.out.println("6. Type comment for specific article");
		System.out.println("7. Send message");
		System.out.println("8. Exit");
	}
	
	public void ChoiceProc() throws SQLException{
		int res; 
		int count = 0;
		String receiver;
		String subject;
		String text;
		int articleID;
		String comment;
		PreparedStatement pst;
		ResultSet rs;
		int choice = sir.readPositiveInt("Please enter one of the above options: ");
		switch(choice){
			case 1:
				try {
					conn = DriverManager.getConnection("jdbc:postgresql://"+sir.readString("Enter IP: ")+":"+sir.readString("Enter Port: ")+"/"+sir.readString("Enter Database Name: "),sir.readString("Type Username:"),sir.readString("Type your Password: "));
					conn.setAutoCommit(false);
					//SERIALIZABLE = one transaction after the other
					conn.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
					System.out.println("Successfully Connected to Database!");
				} catch (SQLException e) {
					System.out.println("An error occured ! Please try again ...");
				}
				break;
			case 2:
				if(conn!=null){
					if(trans){
						System.out.println("There is already an active transaction!");
					}
					else{
						email = sir.readString("Type the email of the user who will affect the following actions: ");	
					}
					trans = true;
				}
				else{
					System.out.println("You must establish a Database connection first!");
				}
				break;
			case 3:
				if(conn!=null && trans){
					for (int i=0;i<logs.size();i++){
						System.out.println(i+". "+logs.get(i));
					}
					if(sir.readString("Are you sure you want to cancel the above actions ? [y/n]: ").equals("y")){
						try{
							logs.clear();
							conn.rollback();
							trans = false;
							System.out.println("Actions Canceled ...");
						}
						catch(SQLException e){
							System.out.println("An error occured in option 4-while trying to commit()-. The error message is: "+ e.getMessage());
						}
					}
				}
				else{
					System.out.println("You must establish a Database connection first OR there is no active transaction!");
				}
				break;
			case 4:
				if(conn!=null && trans){		
					for (int i=0;i<logs.size();i++){
						System.out.println(i+". "+logs.get(i));
					}
					if(sir.readString("Are you sure you want to commit the above actions ? [y/n]: ").equals("y")){
						try{
							logs.clear();
							conn.commit();
							trans = false;
							System.out.println("Actions Commited ...");
						}
						catch(SQLException e){
							System.out.println("An error occured in option 4-while trying to commit()-. The error message is: "+ e.getMessage());
						}
					}
				}
				else{
					System.out.println("You must establish a Database connection first OR there is no active transaction!");
				}
				break;
			case 5:
				if(conn!=null){
					if(trans){
						try{
							pst = conn.prepareStatement("select email1,email2,lvl from public.\"myview\" where email1 = ? and lvl <= ? ");
							pst.setString(1,email);
							pst.setInt(2,sir.readPositiveInt("Type max connectivity level: "));
							System.out.println("====================== Starting Query =======================");
							rs = pst.executeQuery();
							while (rs.next()) {
								System.out.println("Email 1:"+rs.getString(1)+" ,Email 2:"+rs.getString(2)+"  ,Level:"+rs.getInt(3));
							}
							System.out.println("====================== End Of Results =======================");
						}
						catch (SQLException e){
							System.out.println("An error occured in option 5. The error message is: "+ e.getMessage());
						}
					}
					else{
						System.out.println("There isn't a specified email. Start a transaction first");
					}
				}
				else{
					System.out.println("You must establish a Database connection first !");
				}
				break;
			case 6:
				if(conn!=null){
					if(trans){
						try{
							pst = conn.prepareStatement("select count(*) from public.\"Article_Comment\"");
							rs = pst.executeQuery();
							if(rs.next()){
								count = rs.getInt(1) + 1;
							}
							pst = conn.prepareStatement("select articleID,title from public.\"Article\" ");
							System.out.println("====================== Starting Query =======================");
							rs = pst.executeQuery();
							while (rs.next()) {
								System.out.println("ArticleID:"+rs.getInt(1)+" Title:"+rs.getString(2));
							}
							System.out.println("====================== End Of Results =======================");
							articleID = sir.readPositiveInt("Choose one of the above Articles by ArticleID: ");
							comment = sir.readString("Type your comment: ");
							pst = conn.prepareStatement("insert into public.\"Article_Comment\" values(?,?,?,?,?)");
							pst.setInt(1,count);
							pst.setString(2,comment);
							pst.setDate(3,new java.sql.Date(System.currentTimeMillis()));
							pst.setInt(4,articleID);
							pst.setString(5, email);
						    res = pst.executeUpdate();
							logs.add("Comment Entry on article with ArticleID: "+articleID + " and text: " + comment + " and affected " + res + " rows.");	
							System.out.println("Successfully added Comment to table...");
						}
						catch(SQLException e){
							System.out.println("An error occured in option 6. The error message is: "+ e.getMessage());
						}
					}
					else{
						System.out.println("There isn't any active transaction");
					}
				}
				else{
					System.out.println("You must establish a Database connection first!");
				}
				break;
			case 7:
				if(conn!=null){
					if(trans){
						receiver = sir.readString("Type the receiver's email: ");
						subject = sir.readString("Type the subject: ");
						text = sir.readString("Type the message: ");
						pst = conn.prepareStatement("select count(*) from public.\"Article_Comment\"");
						rs = pst.executeQuery();
						if(rs.next()){
							count = rs.getInt(1) + 1;
						}
						pst = conn.prepareStatement("insert into public.\"Msg\"values(?,?,?,?,?,?)");
						pst.setInt(1, count);
						pst.setDate(2,new java.sql.Date(System.currentTimeMillis()));
						pst.setString(3,subject);
						pst.setString(4,text);
						pst.setString(5, email);
						pst.setString(6,receiver);
					    res = pst.executeUpdate();
						logs.add("Message Entry with receiver: "+ receiver + " ,subject: " + subject + " and text:" + text + " and affected " + res + " rows.");
						System.out.println("Successfully added Message to table...");
					}
					else{
						System.out.println("There isn't any active transaction");
					}
				}
				else{
					System.out.println("You must establish a Database connection first!");
				}
				break;
			default :
				if(trans){
					if(!sir.readString("The last transaction was not completed. Do you really want to exit the application ? [y/n]: ").equals("n")){
						cont=false;
					}
				}
				break;
		}
	}	
}
